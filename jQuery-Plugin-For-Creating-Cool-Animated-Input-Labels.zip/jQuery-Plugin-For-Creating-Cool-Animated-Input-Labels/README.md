# Label
Label is a simple jQuery plugin that adds labels for easy HTML5 markup.

View demo here: http://www.brendenpalmer.com/label

## Getting started

You'll need jQuery for this (obviously). The latest version works well. Include it at the end of your HTML right before the closing body tag.

## How to use label?

It's simple. Label requires inputs to have the following markup:

*You can obviously include other HTML5 compliant markup (maxlength, etc.), but these are required at minimum.*

```html
<input type="text" data-label="First name..." />
``` 

**If no data-label parameter is included then a label will not be created for that input.**

To instantiate label the following code (at minimum) is required:

*It's recommended to include jQuery, label.js, and the following snippet at the end of your HTML code, right before the closing body tag.*

```JavaScript
$('input').label();
``` 

## HTML5 markup after plugin is instantiated

```html
<div class="input-parent" style="position:relative;">
	<label class="label" style="font-size:0.9rem;color:#666;">
		First name...
	</label>
	<input type="text" data-label="First name..." />
</div>
```

## Options

The plugin has the following options:

| Option name  | Expected type / example |
| ------------- | ------------- |
| mode  | String (possible options are 'default' OR 'placeholder' OR 'inline');  |
| color  | String (example: "#333");  |
| parentClass  | String (name of parent class, defaults to "input-parent")  |
| labelClass  | String (name of the class used on labels, defaults to "label")  |
| fontSize  | String (example: "0.9rem"). This defaults to the font-size of the input for placeholder mode.  |
| alignText | String (possible options are, 'left', 'center', or 'right');  |
| show  | String (possibilites are: 'default', 'keyup', or 'focus'. If mode is set to 'placeholder' then this option will do nothing.)  |

## Known Issues

Firefox causes some wonky behaviour with inputs if they have something like the following:

```css
input{
	width:100%;
	transition:all 0.5s ease;
}
```

To fix the unintended behaviour simply change the transition to something like:

```css
input{
	width:100%;
	transition:border,background 0.5s ease;
}
```



